<section class="content-header">
      <h1>
        Pesanan
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Pesanan</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="box">
            <div class="box-header">
              <button data-toggle="modal" data-target="#add_fak" class="btn btn-primary"><i class="fa fa-plus"></i>&nbsp&nbsp<i class="fa fa-university"></i></button>
            </div>

            <!--tambah buku-->
                <div class="modal fade" id="add_fak">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Tambah Data Fakultas</h4>
                      </div>
                      <div class="modal-body">
                        <form action="inc/proses.php?proses=inp_fak" method="post">
                        <div class="form-group">
                          <label for="exampleInputEmail1">Nama Fakultas</label>
                          <input type="text" class="form-control" name="namafakultas" placeholder="Nama Fakultas">
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" name="tambah" value="Tambah">
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              <!--end tambah-->

            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Fakultas</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>ghnj</td>
                  <td>dfghj</td>
                  <td align="center">
                    <button data-toggle="modal" data-target="#edit_fak" class="btn btn-primary"><i class="fa fa-edit"></i></button>
                    <button data-toggle="modal" data-target="#del" class="btn btn-danger"><i class="fa fa-trash"></i></button>
                  </td>
                  <!--edit mhs-->
                <div class="modal fade" id="edit_fak">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Edit Data Fakultas</h4>
                      </div>
                      <div class="modal-body">
                        <form action="inc/proses.php?proses=edit_fak" method="post">
                        <div class="form-group">
                          <label for="exampleInputEmail1">Nama Fakultas</label>
                          <input type="hidden" name="idfakultas" value="">
                          <input type="text" class="form-control" name="namafakultas" value="">
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" name="tambah" value="Edit">
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              <!--end edit-->

              <!--Modal Hapus-->
                      <div class="modal fade" id="del" role="dialog">
                      <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Hapus Data</h4>
                          </div>
                          <div class="modal-body">
                            <p>Apakah anda ingin menghapus data fakultas dengan nama <b><?=$data['namafakultas'];?></b>...??</p>
                          </div>
                          <div class="modal-footer">
                            <a href="inc/proses.php?proses=del_fak&id=<?=$data[idfakultas];?>"><button class="btn btn-danger">Hapus</button></a>
                          </div>
                        </div>
                      </div>
                      </div>
              <!--End hapus-->
                </tr>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
    </section>