<section class="content-header">
      <h1>
        Organizer
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Organizer</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="box">

            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Pemilik</th>
                  <th>Kategori</th>
                  <th>Nama Org</th>
                  <th>Slogan</th>
                  <th>Foto</th>
                  <th>Tgl Verif</th>
                  <th>Status</th>
                </tr>
                </thead>
                <tbody>
                  <?php 
                    $no=1;
                    foreach ($organizer as $o => $ro) {
                   ?>
                <tr>
                  <td><?=$no++;?></td>
                  <td><?=$ro->nama;?></td>
                  <td><?=$ro->nama_kat;?></td>
                  <td><?=$ro->nama_or;?></td>
                  <td><?=$ro->slogan;?></td>
                  <td><img width="50px" height="50px" src="<?=base_url()?>images/organizer/<?=$ro->fotor;?>"></td>
                  <td><?=$ro->tgl_verif;?></td>
                  <td align="center">
                    <?php if($ro->status==1){ ?>
                    <a href="<?=base_url('admin/verif/'.$ro->id_organizer)?>"><button class="btn btn-danger">Verifikasi</button></a>
                    <?php }else{ ?>
                    <a href="<?=base_url('admin/unverif/'.$ro->id_organizer)?>"><button class="btn btn-primary">Terverifikasi</button></a>
                    <?php } ?>

                    <button data-toggle="modal" data-target="#del<?=$ro->id_organizer?>" class="btn btn-danger"><i class="fa fa-trash"></i></button>
                  </td>

              <!--Modal Hapus-->
                      <div class="modal fade" id="del<?=$ro->id_organizer?>" role="dialog">
                      <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Hapus Data</h4>
                          </div>
                          <div class="modal-body">
                            <p>Apakah anda ingin menghapus data ini?...??</p>
                          </div>
                          <div class="modal-footer">
                            <a href="<?=base_url('admin/del_or/'.$ro->id_organizer);?>"><button class="btn btn-danger">Hapus</button></a>
                          </div>
                        </div>
                      </div>
                      </div>
              <!--End hapus-->
                </tr>
                <?php } ?>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
    </section>