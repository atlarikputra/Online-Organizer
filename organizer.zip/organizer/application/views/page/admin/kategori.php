<section class="content-header">
      <h1>
        Kategori
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Kategori</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="box">
            <div class="box-header">
              <button data-toggle="modal" data-target="#add_fak" class="btn btn-primary"><i class="fa fa-plus"></i></button>
            </div>

            <!--tambah buku-->
                <div class="modal fade" id="add_fak">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Tambah Kategori</h4>
                      </div>
                      <div class="modal-body">
                        <?=form_open('admin/add_kat');?>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Kategori</label>
                          <input type="text" class="form-control" name="nama_kat" placeholder="Kategori">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Ikon</label>
                          <input type="text" class="form-control" name="ikon" placeholder="Ikon">
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" name="tambah" value="Tambah">
                        <?=form_close();?>
                      </div>
                    </div>
                  </div>
                </div>
              <!--end tambah-->

            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Kategori</th>
                  <th>Ikon</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                  <?php 
                    $no=1;
                    foreach ($kategori as $k => $rk) {
                   ?>
                <tr>
                  <td><?=$no++;?></td>
                  <td><?=$rk->nama_kat;?></td>
                  <td><?=$rk->ikon;?></td>
                  <td align="center">
                    <button data-toggle="modal" data-target="#edit_fak<?=$rk->id_kategori;?>" class="btn btn-primary"><i class="fa fa-edit"></i></button>
                    <button data-toggle="modal" data-target="#del<?=$rk->id_kategori;?>" class="btn btn-danger"><i class="fa fa-trash"></i></button>
                  </td>
                  <!--edit mhs-->
                <div class="modal fade" id="edit_fak<?=$rk->id_kategori?>">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Edit Kategori</h4>
                      </div>
                      <div class="modal-body">
                        <?=form_open('admin/add_kat','',array('id'=>$rk->id_kategori));?>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Kategori</label>
                          <input type="text" class="form-control" name="nama_kat" value="<?=$rk->nama_kat;?>">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Ikon</label>
                          <input type="text" class="form-control" name="ikon" value="<?=$rk->ikon;?>">
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" name="edit" value="Edit">
                        <?=form_close();?>
                      </div>
                    </div>
                  </div>
                </div>
              <!--end edit-->

              <!--Modal Hapus-->
                      <div class="modal fade" id="del<?=$rk->id_kategori?>" role="dialog">
                      <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Hapus Data</h4>
                          </div>
                          <div class="modal-body">
                            <p>Apakah anda ingin menghapus data ini...??</p>
                          </div>
                          <div class="modal-footer">
                            <a href="<?=base_url('admin/del_kat/'.$rk->id_kategori);?>"><button class="btn btn-danger">Hapus</button></a>
                          </div>
                        </div>
                      </div>
                      </div>
              <!--End hapus-->
                </tr>
                <?php } ?>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
    </section>