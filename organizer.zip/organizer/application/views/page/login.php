<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title><?=$judul;?></title>
  
  
  <link rel='stylesheet prefetch' href='http://netdna.bootstrapcdn.com/bootstrap/3.0.2/css/bootstrap.min.css'>

      <link rel="stylesheet" href="<?=base_url();?>css/pricing/login.css">

  
</head>

<body>

    <div class="wrapper">
    <?=form_open('login/auth', array('class'=>'form-signin'));?>
      <h2 class="form-signin-heading">Please login</h2>
      <input type="text" class="form-control" name="username" placeholder="Username" required="" autofocus="" />
      <input type="password" class="form-control" name="password" placeholder="Password" required=""/>      
      <label class="checkbox">
        <input type="checkbox" value="remember-me" id="rememberMe" name="rememberMe"> Remember me
      </label>
      <input class="btn btn-lg btn-primary btn-block" type="submit" value="Login">   
    <?=form_close();?>
  </div>
  
  

</body>

</html>
