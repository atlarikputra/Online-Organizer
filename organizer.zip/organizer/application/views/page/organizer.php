<div class="kotak-header">
	<div class="kotak-header-data"><b><?=$jumlah;?></b> Data ditemukan</div>
	<div class="kotak-header-search">
		<?=form_open('home/cari');?>
			<input type="text" placeholder="Cari Nama Organizer" name="cari">
			<input type="submit" name="search" value="Cari">
		<?=form_close();?>
	</div>
</div>
<?php 
	foreach ($organizer as $o => $ko) {
 ?>
<div class="kotak">
	<div class="kotak1">
		<img src="<?=base_url();?>images/organizer/<?=$ko->fotor;?>" class="gambar-logo">
	</div>
	<div class="kotak2">
		<div class="nama-or"><b><?=$ko->nama_or;?></b></div>
		<div class="pemilik"><i class="fa fa-user"></i> Pemilik : <?=$ko->nama;?></div>
		<div class="lokasi"><i class="fa fa-map-marker"></i> <?=$ko->alamat;?></div>
		<div class="jargon">"<?=$ko->slogan;?>"</div>
	</div>
	<div class="kotak3">
		<div class="fontt">Harga mulai dari<br><font color="#E24343">
			<?php 
				$this->db->where('id_organizer',$ko->id_organizer);
				$this->db->select_min('harga');
				$query=$this->db->get('paket')->result();
				foreach ($query as $p => $rp) {
			 ?>
			 Rp.<?=number_format($rp->harga);?>
			 <?php } ?>
		</font></div>
		<a href="<?=base_url('home/detail/'.$ko->id_organizer);?>"><button class="detil">Preview</button></a>
	</div>
</div>
<?php } ?>
<br>
<!-- Pagination -->
<section>
	<div class="container">
		<div class="row">
			<div class="col-md-5">
				<nav aria-label="Page navigation example">
				  <ul class="pagination">
				    <li class="page-item active"><a class="page-link" href="#">1</a></li>
				    <li class="page-item"><a class="page-link" href="#">2</a></li>
				    <li class="page-item"><a class="page-link" href="#">3</a></li>
				    <li class="page-item">
				      <a class="page-link" href="#" aria-label="Next">
				        <span aria-hidden="true"><i class="fa fa-angle-right"></i></span>
				        <span class="sr-only">Next</span>
				      </a>
				    </li>
				  </ul>
				</nav>
			</div>
		</div>
	</div>
</section>
<br>