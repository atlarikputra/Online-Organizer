<section class="user-profile section">
	<div class="container">
		<div class="row">
			<div class="col-md-10 offset-md-1 col-lg-4 offset-lg-0">
				<div class="sidebar">
					<div class="konfir"><b>Pilihan Anda</b></div>
					<div class="widget user-dashboard-menu">
						

						<div class="demo">
        <div class="container">

            <div class="row">
                <div class="col-md-12 col-sm-6">
                    <div class="pricingTable blue">
                        <div class="pricingTable-header">
                            <span class="heading">
                                <h3><?=$paket->nama_p;?></h3>
                            </span>
                            <span class="price-value">Rp.<?=number_format($paket->harga);?></span>
                        </div>
                        <div class="pricingContent">
                            <ul>
                                <?php 
                                    $this->db->where('id_paket',$paket->id_paket);
                                    $query=$this->db->get('fasilitas')->result();
                                    foreach ($query as $f => $rf) {
                                 ?>
                                <li><?=$rf->fasilitas;?> <i class="fa fa-check"></i></li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


					</div>
				</div>
			</div>
			<div class="col-md-10 offset-md-1 col-lg-8 offset-lg-0">
				<!-- Edit Personal Info -->
				<div class="konfir"><b>Informasi</b></div>
				<div class="widget personal-info">
					<h3 class="widget-header user">Info Pemesanan</h3>
					<div class="attent">Untuk memastikan keyakinan Anda terhadap penyedia Organizer, Anda dapat berkomunuikasi atau sekedar tanya-tanya mengenai organizer yang dipilih lewat pihak ketiga yaitu menggunakan Whatsapp, sms, atau menelpon langsung ke nomor <b>+6285768435297</b>.<br><br></div>
					<a href="whatsapp://send?text=Hello&phone=+6285210539260" class="btn-lg btn-success"><font face="Arial">Chat Whatsapp</font></a><br><br>
					<div class="attent">Jika sudah yakin dengan Organizer yang Anda pilih, Anda dapat langsung memesan dengan mengisikan data pemesanan yang tersedia di bawah ini.</div>
					
				</div>
				<!-- Change Password -->
				<div class="widget change-password">
					<h3 class="widget-header user">Data Pemesanan</h3>
					<?=form_open('home/order');?>
						          <div class="form-group">
                        <label class="col-sm-2 control-label">Kode Pesan</label>
                        <div class="col-sm-12">
                          <input type="text" name="kode_pesan" readonly="readonly" class="form-control" value="<?=$kodeunik;?>">
                          <input type="hidden" name="id_paket" value="<?=$paket->id_paket;?>">
                          <input type="hidden" name="id_user" value="<?=$user->id_user;?>">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-2 control-label">Nama</label>
                        <div class="col-sm-12">
                          <input type="text" name="nama" class="form-control" value="<?=$user->nama;?>">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-2 control-label">Alamat</label>
                        <div class="col-sm-12">
                          <input type="text" name="alamat" class="form-control" value="<?=$user->alamat;?>">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-2 control-label">No Telepon</label>
                        <div class="col-sm-12">
                          <input type="text" name="no_telepon" class="form-control" value="<?=$user->telepon?>">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-4 control-label">Tanggal Pesan</label>
                        <div class="col-sm-12">
                          <input type="date" name="tgl_pesan" readonly="readonly" value="<?=date("Y-m-d");?>" class="form-control">
                        </div>
                      </div>
                      <div class="row">
                      	<div class="col-md-6">
	                      <div class="form-group">
	                        <label class="col-sm-6 control-label">Tangal Pakai</label>
	                        <div class="col-sm-12">
	                          <input type="date" name="tgl_pakai" class="form-control" required="required" placeholder="Tanggal Lahir">
	                        </div>
	                      </div>
	                  	</div>
	                  	<div class="col-md-6">
	                      <div class="form-group">
	                        <label class="col-sm-6 control-label">Sampai Tanggal</label>
	                        <div class="col-sm-12">
	                          <input required="required" type="date" name="tgl_selesai" class="form-control" placeholder="Tanggal Lahir">
	                        </div>
	                      </div>
	                  	</div>
	                  </div>
						<!-- Submit Button -->
							&nbsp&nbsp&nbsp<input class="btn btn-transparent" type="submit" value="Pesan">
					<?=form_close();?>
				</div>
			</div>
		</div>
	</div>
</section>