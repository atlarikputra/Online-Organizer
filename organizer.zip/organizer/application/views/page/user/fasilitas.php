<style type="text/css">
	button{
		border:none;
	}
</style>
<div class="col-md-10 offset-md-1 col-lg-8 offset-lg-0">
	<!-- Edit Personal Info -->
	<div class="widget personal-info">
		<h3 class="widget-header user">Fasilitas</h3>
		

    <!-- Main content -->
    <section class="content">
      <div class="box">
            <div class="box-header">
              <button data-toggle="modal" data-target="#add_progdi" class="btn-lg btn-primary"><i class="fa fa-plus"></i></button>
            </div>

            <!--tambah fasilitas-->
                <div class="modal fade" id="add_progdi">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h4 class="modal-title">Tambah Data Fasilitas</h4>
                      </div>
                      <div class="modal-body">
                        <?=form_open('profil/add_fas');?>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Pilih Organizer yang ingin di tambah fasilitas</label><br>
                          <select name="id_organizer" class="form-control">
                            <option value="0">&nbspPilih&nbsp</option>
                            <?php 
                              foreach ($organizer as $o => $ro) {
                                foreach ($paketa as $p => $rp) {
                                  if($ro->id_organizer==$rp->id_organizer){
                             ?>
                             <option value="<?=$rp->id_organizer?>"><?=$ro->nama_or;?></option>
                             <?php }}} ?>
                          </select>
                        </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Pilih Paket yang ingin di tambah fasilitas</label><br>
                          <select name="id_paket" class="form-control">
                            <option value="0">Pilih</option>
                            <?php 
                              foreach ($paket as $p => $rp) {
                              foreach ($organizer as $nm => $rno){
                                if($rp->id_organizer==$rno->id_organizer){
                             ?>
                             <option value="<?=$rp->id_paket;?>"><?=$rp->nama_p;?> (<?=$rno->nama_or;?>)</option>
                             <?php }}} ?>
                          </select>
                        </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Fasilitas</label>
                          <input type="text" class="form-control" name="fasilitas" placeholder="Tambahkan Fasilitas">
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" name="add_fas" value="Tambah">
                        <?=form_close();?>
                      </div>
                    </div>
                  </div>
                </div>
              <!--end tambah-->

            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Organizer</th>
                  <th>Nama Paket</th>
                  <th>Fasilitas</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                  <?php 
                    $no=1;
                    foreach ($fasilitas as $f => $rf) {
                      foreach ($organizer as $nm => $rno){
                        if($rf->id_organizer==$rno->id_organizer){
                   ?>
              	<tr>
              		<td><?=$no++;?></td>
              		<td><?=$rno->nama_or;?></td>
                  <td><?=$rf->nama_p;?></td>
                  <td><?=$rf->fasilitas;?></td>
              		<td>
                    <button class="btn-sm btn-primary" data-toggle="modal" data-target="#edit_fas<?=$rf->id_fasilitas;?>"><i class="fa fa-edit"></i></button></button>
                  </td>
              	</tr>

                <!--End fasilitas-->
                <div class="modal fade" id="edit_fas<?=$rf->id_fasilitas;?>">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h4 class="modal-title">Tambah Data Fasilitas</h4>
                      </div>
                      <div class="modal-body">
                        <?=form_open('profil/add_fas','',array('id'=>$rf->id_fasilitas));?>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Pilih Organizer yang ingin di tambah fasilitas</label><br>
                          <select name="id_organizer" class="form-control">
                            <option value="0">&nbspPilih&nbsp</option>
                            <?php 
                              foreach ($organizer as $o => $ro) {
                                foreach ($paketa as $p => $rp) {
                                  if($ro->id_organizer==$rp->id_organizer){
                             ?>
                             <option <?php if($rf->id_organizer==$rp->id_organizer){echo "selected='selected'";} ?> value="<?=$rp->id_organizer?>"><?=$ro->nama_or;?></option>
                             <?php }}} ?>
                          </select>
                        </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Pilih Paket yang ingin di tambah fasilitas</label><br>
                          <select name="id_paket" class="form-control">
                            <option value="0">Pilih</option>
                            <?php 
                              foreach ($paket as $p => $rp) {
                              foreach ($organizer as $nm => $rno){
                                if($rp->id_organizer==$rno->id_organizer){
                             ?>
                             <option <?php if($rf->id_paket==$rp->id_paket){echo "selected='selected'";} ?> value="<?=$rp->id_paket;?>"><?=$rp->nama_p;?> (<?=$rno->nama_or;?>)</option>
                             <?php }}} ?>
                          </select>
                        </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Fasilitas</label>
                          <input type="text" class="form-control" name="fasilitas" value="<?=$rf->fasilitas;?>">
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" name="edit_fas" value="Edit">
                        <?=form_close();?>
                      </div>
                    </div>
                  </div>
                </div>
              <!--end tambah-->

                <?php }}} ?>
              </table>
              <!-- Pagination -->
				<section>
					<div class="container">
						<div class="row">
							<div class="col-md-5">
								<nav aria-label="Page navigation example">
								  <ul class="pagination">
								    <li class="page-item active"><a class="page-link" href="#">1</a></li>
								    <li class="page-item"><a class="page-link" href="#">2</a></li>
								    <li class="page-item"><a class="page-link" href="#">3</a></li>
								    <li class="page-item">
								      <a class="page-link" href="#" aria-label="Next">
								        <span aria-hidden="true"><i class="fa fa-angle-right"></i></span>
								        <span class="sr-only">Next</span>
								      </a>
								    </li>
								  </ul>
								</nav>
							</div>
						</div>
					</div>
				</section>


            </div>
            <!-- /.box-body -->
          </div>
    </section>
	</div>
</div>