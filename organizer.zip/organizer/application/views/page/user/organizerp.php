<style type="text/css">
	button{
		border:none;
	}
</style>
<div class="col-md-10 offset-md-1 col-lg-8 offset-lg-0">


  <!--modal-->
  <div id="open-modal" class="modal-window">
  <div>
    <a href="#modal-close" title="Close" class="modal-close">close ×</a>
    <h1>Peringatan</h1>
    <div>Ukuran foto yang anda masukkan terlalu besar</div>
  </div>
</div>
  <!--end-->


	<!-- Edit Personal Info -->
	<div class="widget personal-info">
		<h3 class="widget-header user">Organizerku</h3>
		

    <!-- Main content -->
    <section class="content">
      <div class="box">
            <div class="box-header">
              <button data-toggle="modal" data-target="#add_progdi" class="btn-lg btn-primary"><i class="fa fa-plus"></i></button>
            </div>

            <!--tambah buku-->
                <div class="modal fade" id="add_progdi">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h4 class="modal-title">Tambah Data Organizer</h4>
                      </div>
                      <div class="modal-body">
                        <?=form_open_multipart('profil/add_organizer','',array('id_user'=>$user->id_user));?>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Nama Organizer</label>
                          <input type="text" class="form-control" name="nama_or" placeholder="Nama Organizer">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Kategori</label><br>
                          <select name="id_kategori" class="form-control">
                            <option value="0">Pilih</option>
                            <?php 
                              foreach ($kategori as $k => $rk) {
                             ?>
                             <option value="<?=$rk->id_kategori;?>"><?=$rk->nama_kat;?></option>
                             <?php } ?>
                          </select>
                        </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Slogan</label>
                          <input type="text" class="form-control" name="slogan" placeholder="Examp : Melayani dengan baik">
                        </div>
                        <div class="form-group choose-file">
                          <i class="fa fa-user text-center"></i>
                            <input type="file" class="form-control-file d-inline" name="foto" id="input-file">
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" name="add_or" value="Tambah">
                        <?=form_close();?>
                      </div>
                    </div>
                  </div>
                </div>
              <!--end tambah-->

            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Organizer</th>
                  <th>Kategori</th>
                  <th>Slogan</th>
                  <th>Foto</th>
                  <th>status</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                  <?php 
                    $no=1;
                    foreach ($organizer as $or => $ro) {
                   ?>
              	<tr>
              		<td><?=$no++;?></td>
              		<td><?=$ro->nama_or?></td>
                  <td><?=$ro->nama_kat?></td>
                  <td><?=substr($ro->slogan,0,25);?>...</td>
                  <td><img width="50px" height="50px" src="<?=base_url();?>images/organizer/<?=$ro->fotor?>"></td>
              		<td>
                    <?php if($ro->status==0){ ?>
                    <button class="btn-sm btn-primary">Verivied</button>
                    <?php }else{ ?>
                    <button class="btn-sm btn-danger">Unverivied</button>
                    <?php } ?>
                  </td>
              		<td>
                    <button class="btn-sm btn-primary" data-toggle="modal" data-target="#edit<?=$ro->id_organizer;?>"><i class="fa fa-edit"></i></button></button>
                  </td>
              	</tr>

                <!--Edir or-->
                <div class="modal fade" id="edit<?=$ro->id_organizer;?>">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h4 class="modal-title">Edit Data Organizer</h4>
                      </div>
                      <div class="modal-body">
                        <?=form_open_multipart('profil/add_organizer','',array('id_user'=>$user->id_user,'id_or'=>$ro->id_organizer));?>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Nama Organizer</label>
                          <input type="text" class="form-control" name="nama_or" value="<?=$ro->nama_or;?>">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Kategori</label><br>
                          <select name="id_kategori" class="form-control">
                            <option value="0">Pilih</option>
                            <?php 
                              foreach ($kategori as $k => $rk) {
                             ?>
                             <option <?php if($rk->id_kategori==$ro->id_kategori){echo "selected='selected'";} ?> value="<?=$rk->id_kategori;?>"><?=$rk->nama_kat;?></option>
                             <?php } ?>
                          </select>
                        </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Slogan</label>
                          <input type="text" class="form-control" name="slogan" value="<?=$ro->slogan;?>">
                        </div>
                        <div class="form-group choose-file">
                          <i class="fa fa-user text-center"></i>
                            <input type="file" class="form-control-file d-inline" name="foto" id="input-file">
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" name="edit_or" value="Edit">
                        <?=form_close();?>
                      </div>
                    </div>
                  </div>
                </div>
              <!--end edit-->
                <?php } ?>
              </table>
              <!-- Pagination -->
				<section>
					<div class="container">
						<div class="row">
							<div class="col-md-5">
								<nav aria-label="Page navigation example">
								  <ul class="pagination">
								    <li class="page-item active"><a class="page-link" href="#">1</a></li>
								    <li class="page-item"><a class="page-link" href="#">2</a></li>
								    <li class="page-item"><a class="page-link" href="#">3</a></li>
								    <li class="page-item">
								      <a class="page-link" href="#" aria-label="Next">
								        <span aria-hidden="true"><i class="fa fa-angle-right"></i></span>
								        <span class="sr-only">Next</span>
								      </a>
								    </li>
								  </ul>
								</nav>
							</div>
						</div>
					</div>
				</section>


            </div>
            <!-- /.box-body -->
          </div>
    </section>
	</div>
</div>