<div class="col-md-10 offset-md-1 col-lg-8 offset-lg-0">
	<!-- Edit Personal Info -->
	<div class="widget personal-info">
		<h3 class="widget-header user">Edit Informasi Pribadi</h3>
		<?=form_open_multipart('profil/edit_data_diri','', array('id'=>$user->id_user));?>
			<!-- First Name -->
			<div class="form-group">
			    <label for="first-name">Nama</label>
			    <input type="text" class="form-control" name="nama" value="<?=$user->nama;?>" id="first-name">
			</div>
			<!-- Last Name -->
			<div class="form-group">
			    <label for="last-name">Alamat</label>
			    <input type="text" name="alamat" class="form-control" value="<?=$user->alamat;?>" id="last-name">
			</div>
			<!-- File chooser -->
			<div class="form-group choose-file">
				<i class="fa fa-user text-center"></i>
			    <input type="file" class="form-control-file d-inline" name="foto" id="input-file">
			 </div>
			<!-- Comunity Name -->
			<div class="form-group">
			    <label for="comunity-name">Email</label>
			    <input type="email" name="email" class="form-control" value="<?=$user->email;?>" id="comunity-name">
			</div>
			<!-- Zip Code -->
			<div class="form-group">
			    <label for="zip-code">No Telepon</label>
			    <input type="text" name="telepon" value="<?=$user->telepon;?>" class="form-control" id="zip-code">
			</div>
			<!-- Submit button -->
			<input class="btn btn-transparent" type="submit" value="Simpan Perubahan">
		<?=form_close();?>
	</div>
	<!-- Change Password -->
	<div class="widget change-password">
		<h3 class="widget-header user">Edit Password</h3>
		<?=form_open('profil/edit_pass','',array('username'=>$user->username));?>
			<!-- Current Password -->
			<div class="form-group">
			    <label for="current-password">Password Saat Ini</label>
			    <input type="password" name="curpass" class="form-control" id="current-password">
			</div>
			<!-- New Password -->
			<div class="form-group">
			    <label for="new-password">Password Baru</label>
			    <input type="password" name="newpass" class="form-control" id="new-password">
			</div>
			<!-- Confirm New Password -->
			<div class="form-group">
			    <label for="confirm-password">Konfirmasi Password Baru</label>
			    <input type="password" name="newpassconfir" class="form-control" id="confirm-password">
			</div>
			<!-- Submit Button -->
			<button class="btn btn-transparent">Simpan Perubahan</button>
		<?=form_close();?>
	</div>
	<!-- Change Email Address -->
	<div class="widget change-email mb-0">
		<h3 class="widget-header user">Edit Username</h3>
		<?=form_open('profil/edit_username','',array('username'=>$user->username));?>
			<!-- Current Password -->
			<div class="form-group">
			    <label for="current-email">Username Saat Ini</label>
			    <input type="text" name="curusername" class="form-control">
			</div>
			<!-- New email -->
			<div class="form-group">
			    <label for="new-email">Username Baru</label>
			    <input type="text" name="newusername" class="form-control">
			</div>
			<!-- Submit Button -->
			<button class="btn btn-transparent">Simpan Perubahan</button>
		<?=form_close();?>
	</div>
</div>