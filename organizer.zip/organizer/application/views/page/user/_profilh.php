<style type="text/css">
	img[name="fprofil"]{
		border-radius: 100%;
		width: 100px;
		height: 90px;
		border: 5px solid #F4F7F9;
	}
</style>
<section class="dashboard section">
	<!-- Container Start -->
	<div class="container">
		<!-- Row Start -->
		<div class="row">
			<div class="col-md-10 offset-md-1 col-lg-4 offset-lg-0">
				<div class="sidebar">
					<!-- User Widget -->
					<div class="widget user-dashboard-profile">
						<!-- User Image -->
						<div class="profile-thumb">
							<?php if($user->foto){ ?>
							<img src="<?=base_url();?>images/user/<?=$user->foto;?>" name="fprofil">
							<?php }else{ ?>
							<img src="<?=base_url();?>images/user/ikon.png" alt="" class="rounded-circle">
							<?php } ?>
						</div>
						<!-- User Name -->
						<h5 class="text-center"><?=$user->nama;?></h5>
						<a href="<?=base_url('profil');?>" class="btn btn-main-sm">Edit Profile</a>
					</div>
					<!-- Dashboard Links -->
					<div class="widget user-dashboard-menu">
						<ul>
							<li class="<?php if($act=='organizerku'){echo "active";} ?>"><a href="<?=base_url('profil/organizerp');?>"><i class="fa fa-user"></i> Organizerku</a></li>
							<li class="<?php if($act=='paket'){echo "active";} ?>"><a href="<?=base_url('profil/paket');?>"><i class="fa fa-bookmark-o"></i> Paket Organizer</a></li>
							<li class="<?php if($act=='fasilitas'){echo "active";} ?>"><a href="<?=base_url('profil/fasilitas');?>"><i class="fa fa-file-archive-o"> </i> Fasilitas</a></li>
							<li class="<?php if($act=='pesanan'){echo "active";} ?>"><a href="<?=base_url('profil/pesanan');?>"><i class="fa fa-bolt"></i> Pesanan Masuk</a></li>
							<li><a href=""><i class="fa fa-cog"></i> Logout</a></li>
						</ul>
					</div>
				</div>
			</div>