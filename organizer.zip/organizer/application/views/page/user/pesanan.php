<style type="text/css">
	button{
		border:none;
	}
</style>
<div class="col-md-10 offset-md-1 col-lg-8 offset-lg-0">
	<!-- Edit Personal Info -->
	<div class="widget personal-info">
		<h3 class="widget-header user">Pesanan Masuk</h3>
		

    <!-- Main content -->
    <section class="content">
      <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Organizer</th>
                  <th>Nama Paket</th>
                  <th>Pemesan</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php 
                  $no=1;
                  foreach ($pesanan as $ps => $rps) {
                    foreach ($organizer as $o => $ro) {
                      if($rps->id_organizer==$ro->id_organizer){
                 ?>
              	<tr>
                  <td><?=$no++;?></td>
                  <td><?=$ro->nama_or;?></td>
                  <td><?=$rps->nama_p;?></td>
                  <td>
                    <a href="<?=base_url('profil/detail_pesanan/'.$rps->id_pesan);?>"><button class="btn-sm btn-primary">Detail Pemesan</button></a>
                  </td>
                  <td>
                    <a href="<?=base_url('profil/del_pesan/'.$rps->id_pesan);?>"><button class="btn-sm btn-danger"><i class="fa fa-trash"></i></button></a>
                  </td>
                </tr>
                <?php }}} ?>
              </table>
              <!-- Pagination -->
				<section>
					<div class="container">
						<div class="row">
							<div class="col-md-5">
								<nav aria-label="Page navigation example">
								  <ul class="pagination">
								    <li class="page-item active"><a class="page-link" href="#">1</a></li>
								    <li class="page-item"><a class="page-link" href="#">2</a></li>
								    <li class="page-item"><a class="page-link" href="#">3</a></li>
								    <li class="page-item">
								      <a class="page-link" href="#" aria-label="Next">
								        <span aria-hidden="true"><i class="fa fa-angle-right"></i></span>
								        <span class="sr-only">Next</span>
								      </a>
								    </li>
								  </ul>
								</nav>
							</div>
						</div>
					</div>
				</section>


            </div>
            <!-- /.box-body -->
          </div>
    </section>
	</div>
</div>