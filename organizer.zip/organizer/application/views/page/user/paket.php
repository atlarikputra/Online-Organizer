<style type="text/css">
	button{
		border:none;
	}
</style>
<div class="col-md-10 offset-md-1 col-lg-8 offset-lg-0">
	<!-- Edit Personal Info -->
	<div class="widget personal-info">
		<h3 class="widget-header user">Paket Organizer</h3>
		

    <!-- Main content -->
    <section class="content">
      <div class="box">
            <div class="box-header">
              <button data-toggle="modal" data-target="#add_progdi" class="btn-lg btn-primary"><i class="fa fa-plus"></i></button>
            </div>

            <!--tambah buku-->
                <div class="modal fade" id="add_progdi">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h4 class="modal-title">Tambah Data Paket Organizer</h4>
                      </div>
                      <div class="modal-body">
                        <?=form_open('profil/add_paket');?>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Nama Organizer</label><br>
                          <select name="id_organizer" class="form-control">
                            <option value="0">Pilih</option>
                            <?php 
                              foreach ($organizer as $nm => $rno) {
                             ?>
                             <option value="<?=$rno->id_organizer;?>"><?=$rno->nama_or;?></option>
                             <?php } ?>
                          </select>
                        </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Nama Paket</label>
                          <input type="text" class="form-control" name="nama_p" placeholder="Nama Paket">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Harga yang ditawarkan</label>
                          <input type="number" class="form-control" name="harga" placeholder="Harga penawaran">
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" name="add_paket" value="Tambah">
                        <?=form_close();?>
                      </div>
                    </div>
                  </div>
                </div>
              <!--end tambah-->

            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Organizer</th>
                  <th>Nama Paket</th>
                  <th>Harga</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                  <?php 
                    $no=1;
                    foreach ($paket as $p => $rp) {
                    foreach ($organizer as $nm => $rno){
                      if($rp->id_organizer==$rno->id_organizer){
                   ?>
              	<tr>
              		<td><?=$no++;?></td>
              		<td><?=$rp->nama_or;?></td>
                  <td><?=$rp->nama_p;?></td>
                  <td>Rp.<?=number_format($rp->harga);?></td>
              		<td>
                    <button class="btn-sm btn-primary" data-toggle="modal" data-target="#edit_paket<?=$rp->id_paket?>"><i class="fa fa-edit"></i></button></button>
                  </td>
              	</tr>

                <!--Edit paket-->
                <div class="modal fade" id="edit_paket<?=$rp->id_paket?>">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h4 class="modal-title">Edit Data Paket Organizer</h4>
                      </div>
                      <div class="modal-body">
                        <?=form_open('profil/add_paket','',array('id'=>$rp->id_paket));?>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Nama Organizer</label><br>
                          <select name="id_organizer" class="form-control">
                            <option value="0">Pilih</option>
                            <?php 
                              foreach ($organizer as $nm => $rno) {
                             ?>
                             <option <?php if($rp->id_organizer==$rno->id_organizer){echo "selected='selected'";} ?> value="<?=$rno->id_organizer;?>"><?=$rno->nama_or;?></option>
                             <?php } ?>
                          </select>
                        </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Nama Paket</label>
                          <input type="text" class="form-control" name="nama_p" value="<?=$rp->nama_p;?>">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Harga yang ditawarkan</label>
                          <input type="number" class="form-control" name="harga" value="<?=$rp->harga;?>">
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                        <input type="submit" class="btn btn-primary" name="edit_paket" value="edit_paket">
                        <?=form_close();?>
                      </div>
                    </div>
                  </div>
                </div>
              <!--End-->

                <?php }}} ?>
              </table>
              <!-- Pagination -->
				<section>
					<div class="container">
						<div class="row">
							<div class="col-md-5">
								<nav aria-label="Page navigation example">
								  <ul class="pagination">
								    <li class="page-item active"><a class="page-link" href="#">1</a></li>
								    <li class="page-item"><a class="page-link" href="#">2</a></li>
								    <li class="page-item"><a class="page-link" href="#">3</a></li>
								    <li class="page-item">
								      <a class="page-link" href="#" aria-label="Next">
								        <span aria-hidden="true"><i class="fa fa-angle-right"></i></span>
								        <span class="sr-only">Next</span>
								      </a>
								    </li>
								  </ul>
								</nav>
							</div>
						</div>
					</div>
				</section>


            </div>
            <!-- /.box-body -->
          </div>
    </section>
	</div>
</div>