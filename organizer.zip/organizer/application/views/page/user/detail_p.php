<style type="text/css">
	button{
		border:none;
	}
</style>
<div class="col-md-10 offset-md-1 col-lg-8 offset-lg-0">
	<!-- Edit Personal Info -->
	<div class="widget personal-info">
		<h3 class="widget-header user">Detail Pesanan Masuk</h3>
		

    <!-- Main content -->
    <section class="content">
      <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Nama Pemesan</th>
                  <th>Kode pesan</th>
                  <th>No Telepon</th>
                  <th>Email</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td><?=$pesanan->nama;?></td>
                  <td><?=$pesanan->kode_pesan?></td>
                  <td><?=$pesanan->telepon;?></td>
                  <td><?=$pesanan->email;?></td>
                </tr>
              </table>
              <table class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Tgl Pesan</th>
                  <th>Pakai</th>
                  <th>Selesai</th>
                </tr>
                </thead>
                <tbody>
              	<tr>
                  <td><?=date("d-M-Y", strtotime($pesanan->tgl_pesan))?></td>
                  <td><?=date("d-M-Y", strtotime($pesanan->tgl_pakai))?></td>
                  <td><?=date("d-M-Y", strtotime($pesanan->tgl_selesai))?></td>
                </tr>
              </table>

            </div>
            <!-- /.box-body -->
          </div>
    </section>
	</div>
</div>