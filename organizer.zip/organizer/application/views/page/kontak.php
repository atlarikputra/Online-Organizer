<section class="user-profile section">
  <div class="container">
    <div class="row">
      <div class="col-md-10 offset-md-1 col-lg-4 offset-lg-0">
        <div class="sidebar">
          <div class="widget user-dashboard-menu">
          <h3 class="widget-header user">Hubungi kami</h3>
            <ul>
                <li><label><strong>Telepon : </strong></label>
                  <p>
                    +6285678564321
                  </p>
                </li>
                <li><label><strong>Email : </strong></label>
                  <p>
                    onlineorganizer@gmail.com
                  </p>
                </li>
                <li><label><strong>Alamat : </strong></label>
                  <p>
                    Jl. Menoreh Raya, No 1, Semarang, Jawa Tengah
                  </p>
                </li>
              </ul>
          </div>
        </div>
      </div>
      <div class="col-md-10 offset-md-1 col-lg-8 offset-lg-0">
              <div class="widget personal-info">
                <h3 class="widget-header user">Tinggalkan Pesan Untuk Kami</h3>
                <?=form_open();?>
                  <div class="row">
                    <div class="col-md-6">
                      <input type="text" name="nama" class="form-control" placeholder="Nama">
                    </div><br><br><br>
                    <div class="col-md-6">
                      <input type="email" name="email" class="form-control" placeholder="Email">
                    </div><br><br><br>
                    <div class="col-md-12">
                      <input type="text" name="subjek" class="form-control" placeholder="Subjek">
                    </div><br><br><br>
                    <div class="col-md-12">
                      <textarea class="form-control" style="height: 100px;" name="pesan" rows="10" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                    </div><br><br><br><br><br>
                    <div class="col-md-12">
                      <input type="submit" class="btn btn-transparent" name="kirim" value="Kirim Pesan">
                    </div>
                  </div>
                <?=form_close();?>
        </div>
      </div>
    </div>
  </div>
</section>