<div class="kotakd">
	<div class="kotak1d">
		<img src="<?=base_url();?>images/organizer/<?=$organizer->fotor;?>" class="gambar-logod">
	</div>
	<div class="kotak2d">
		<div class="nama-or"><b><?=$organizer->nama_or;?></b></div>
		<table class="d-prof" cellpadding="1">
			<tr>
				<td width="30%">Pemilik</td>
				<td>:</td>
				<td><?=$user->nama;?></td>
			</tr>
			<tr>
				<td>Lokasi</td>
				<td>:</td>
				<td><?=$user->alamat;?></td>
			</tr>
			<tr>
				<td>No Hp / Whatshapp</td>
				<td>:</td>
				<td><?=$user->telepon;?></td>
			</tr>
		</table>
	</div>
</div>
 <div class="demo">
        <div class="container">
            <div class="row text-center">
                <h1 class="heading-title">Pilihan Paket</h1>
            </div>

            <div class="row">
                <?php 
                    foreach ($paket as $p => $pr) {
                 ?>
                <div class="col-md-3 col-sm-6">
                    <div class="pricingTable blue">
                        <div class="pricingTable-header">
                            <span class="heading">
                                <h3><?=$pr->nama_p;?></h3>
                            </span>
                            <span class="price-value">Rp.<?=number_format($pr->harga);?>
                        </div>
                        <div class="pricingContent">
                            <ul>
                                <?php 
                                    $this->db->where('id_paket',$pr->id_paket);
                                    $query=$this->db->get('fasilitas')->result();
                                    foreach ($query as $f => $rf) {
                                 ?>
                                <li><?=$rf->fasilitas;?> <i class="fa fa-check"></i></li>
                                <?php } ?>
                            </ul>
                        </div><!-- /  CONTENT BOX-->
                        <div class="pricingTable-sign-up">
                            <a href="

                                <?php if($this->session->userdata('username')){?><?=base_url('home/pesan/'.$pr->id_paket);?><?php }else{ ?>#salah<?php } ?>
                            " class="btn-lg btn-danger">Pilih</a>
                        </div><!-- BUTTON BOX-->
                    </div>
                </div>
                <?php } ?>
                
            </div>
        </div>
    </div>