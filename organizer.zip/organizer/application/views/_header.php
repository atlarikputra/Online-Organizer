<!DOCTYPE html>
<html lang="en">
<head>
  <style type="text/css">
  	.tombol{
  background: none;
  border: 1px solid#999;
  border-radius: 3px;
  padding: 9px;
}
.tombol:hover{
  background: #746BCB;
  color: #FFF;
  transition:all 100ms linear;
}
  </style>
  <link rel="stylesheet" type="text/css" href="<?=base_url();?>css/baru.css">
  <!-- SITE TITTLE -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?=$judul;?></title>
  
  <!-- PLUGINS CSS STYLE -->
  <!-- Bootstrap -->
  <link href="<?=base_url();?>plugins/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="<?=base_url();?>plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <!-- Table -->
  <link rel="stylesheet" href="<?=base_url();?>css/dataTables.bootstrap.min.css">
  <link rel="stylesheet" href="<?=base_url();?>css/dataTables.bootstrap.css">
  <!-- Owl Carousel -->
  <link href="<?=base_url();?>plugins/slick-carousel/slick/slick.css" rel="stylesheet">
  <link href="<?=base_url();?>plugins/slick-carousel/slick/slick-theme.css" rel="stylesheet">
  <!-- Fancy Box -->
  <link href="<?=base_url();?>plugins/fancybox/jquery.fancybox.pack.css" rel="stylesheet">
  <link href="<?=base_url();?>plugins/jquery-nice-select/css/nice-select.css" rel="stylesheet">
  <link href="<?=base_url();?>plugins/seiyria-bootstrap-slider/dist/css/bootstrap-slider.min.css" rel="stylesheet">
  <!-- CUSTOM CSS -->
  <link href="<?=base_url();?>css/style.css" rel="stylesheet" type="text/css">

  <!-- PRICING -->
  	<link rel="stylesheet" href="<?=base_url();?>https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="<?=base_url();?>https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
	<meta charset="utf-8">
	<link rel="stylesheet" href="<?=base_url();?>css/pricing/style.css">
	<meta charset="utf-8">
  <!-- END PRICING -->


  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <style type="text/css">
  	img[name="logo"]{
  		width: 160px;
  		height: 70px;
  	}
  </style>
</head>

<body class="body-wrapper">

<div class="coba">
<section>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<nav class="navbar navbar-expand-lg navigation">
					<a class="navbar-brand" href="<?=base_url('home');?>">
						<img src="<?=base_url();?>images/logo/logob1.png" name="logo">
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<i class="fa fa-navicon"></i>
					</button>
					<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<ul class="navbar-nav ml-auto main-nav ">
							<li class="<?php if($act=='home'){echo "nav-item active";}else{echo "nav-item";} ?>">
								<a class="nav-link" href="<?=base_url('home');?>">Home</a>
							</li>
							<li class="<?php if($act=='tentang'){echo "nav-item active";}else{echo "nav-item";} ?>">
								<a class="nav-link" href="<?=base_url('home/tentang');?>">Tentang</a>
							</li>
              <li class="<?php if($act=='kontak'){echo "nav-item active";}else{echo "nav-item";} ?>">
                <a class="nav-link" href="<?=base_url('home/kontak');?>">Kontak</a>
              </li>
						</ul>

            <?php if($this->session->userdata('username')){ ?>
            <ul class="navbar-nav ml-auto mt-10">
              <br>
              <li class="nav-item">
                <a class="nav-link login-button" href="<?=base_url('profil');?>">Profil</i></a>&nbsp
              </li>
              <li class="nav-item">
                <a class="nav-link add-button" href="<?=base_url('login/logout');?>"><i class="fa fa-lock"></i>&nbsp Logout</a>
              </li>
            </ul>
            <?php }else{ ?>
						<ul class="navbar-nav ml-auto mt-10">
							<br>
							<li class="nav-item">
								<a class="nav-link login-button" href="<?=base_url('home/login');?>">Login</i></a>&nbsp
							</li>
							<li class="nav-item">
								<a class="nav-link add-button" href="<?=base_url('home/signup');?>"><i class="fa fa-plus-circle"></i> Registrasi</a>
							</li>
						</ul>
            <?php } ?>

					</div>
				</nav>
			</div>
		</div>
	</div>
</section>
</div>
			