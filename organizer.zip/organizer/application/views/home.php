<style type="text/css">
	.row-centered{
		margin: auto;
	}
</style>
<!--===============================
=            Hero Area            =
================================-->

<section class="hero-area bg-1 text-center overly">
	<!-- Container Start -->
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<!-- Header Contetnt -->
				<div class="content-block">
					<h1>Online Organizer</h1>
					<p>Website Pencarian Organizer <br> Membantu menemukan Organizer untuk Acara Anda</p>
					<div class="short-popular-category-list text-center">
						<h2>Kategori</h2>
						<ul class="list-inline">
							<?php 
								foreach ($kategori as $k => $rk) {
							 ?>
							<li class="list-inline-item">
								<a href="<?=base_url('home/organizer/'.$rk->id_kategori);?>"><i class="<?=$rk->ikon;?>"></i> <?=$rk->nama_kat;?></a>
							</li>
							 <?php } ?>
						</ul>
					</div>
					
				</div>
				
			</div>
		</div>
	</div>
	<!-- Container End -->
</section>

<!--==========================================
=            All Category Section            =
===========================================-->

<section class=" section">
	<!-- Container Start -->
	<div class="container">
		<div class="row">
			<div class="col-12">
				<!-- Section title -->
				<div class="section-title">
					<h2>All Categories</h2>
				</div>
				<center>
				<div class="row">
					<?php 
						foreach ($kategori as $kat => $rkat) {
					 ?>
					<!-- Category list -->
					<div class="col-lg-3 offset-lg-0 col-md-5 offset-md-1 col-sm-6 col-6 row-centered">
						<div class="category-block">
							<div class="header">
								<i class="<?=$rkat->ikon;?> icon-bg-3"></i> 
								<h4><?=$rkat->nama_kat;?></h4>
							</div>
							<div class="text-center">
							<a href="<?=base_url('home/organizer/'.$rkat->id_kategori);?>" class="btn-lg btn-primary"><font face="Arial" size="+1">Lihat</font></a>
							</div>
						</div>
					</div> <!-- /Category List -->
					<?php } ?>
				</div>
			</center>
			</div>
		</div>
	</div>
	<!-- Container End -->
</section>