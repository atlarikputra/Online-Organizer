<?php 
	class Home extends CI_Controller{
		function __construct(){
			parent::__construct();
			$this->load->model('Mproses');
		}
		public function index(){
			$kat=$this->Mproses->getkat();
			$data=array(
				'judul'=>'Online Organizer',
				'act'=>'home',
				'kategori'=>$kat->result()
			);
			$this->load->view('_header', $data);
			$this->load->view('home');
			$this->load->view('_footer');

		}
		public function organizer($id){
			$getor=$this->Mproses->getorw($id);
			$jml=$this->Mproses->getorw($id);
			$jmlor=$jml->num_rows();
			$data=array(
				'judul'=>'Organizer',
				'act'=>'',
				'organizer'=>$getor->result(),
				'jumlah'=>$jmlor
			);
			$this->load->view('_header', $data);
			$this->load->view('page/organizer');
			$this->load->view('_footer');
		}
		public function detail($id){
			$organizer=$this->Mproses->getorid($id)->row();
			$idusr=$organizer->id_user;
			$getuserid=$this->Mproses->gtuserid($idusr);
			$paket=$this->Mproses->gtpaket($id);
			$data=array(
				'judul'=>'Detail',
				'act'=>'',
				'paket'=>$paket->result(),
				'organizer'=>$organizer,
				'user'=>$getuserid->row()
			);
			$this->load->view('_header', $data);
			$this->load->view('page/detail');
			$this->load->view('_footer');	
		}
		public function pesan($id){
			$gtpkt=$this->Mproses->getpaketid($id);
			$user=$this->session->userdata('username');
			$getuser=$this->Mproses->gtuser($user);
			$data=array(
				'judul'=>'Pesan',
				'act'=>'',
				'paket'=>$gtpkt->row(),
				'user'=>$getuser->row(),
				'kodeunik'=>$this->Mproses->buat_kode()
			);
			$this->load->view('_header', $data);
			$this->load->view('page/pesan');
			$this->load->view('_footer');	
		}
		public function login(){
			$data=array(
				'judul'=>'Login'
			);
			$this->load->view('page/login', $data);
		}
		public function signup(){
			$data=array(
				'judul'=>'Registrasi'
			);
			$this->load->view('page/registrasi', $data);	
		}
		public function kontak(){
			$data=array(
				'judul'=>'Kontak',
				'act'=>'kontak'
			);
			$this->load->view('_header', $data);
			$this->load->view('page/kontak');
			$this->load->view('_footer');
		}
		public function tentang(){
			$data=array(
				'judul'=>'Tentang',
				'act'=>'tentang'
			);
			$this->load->view('_header', $data);
			$this->load->view('page/tentang');
			$this->load->view('_footer');
		}
		public function regis(){
			$data=array(
				'nama'=>$_POST['nama'],
				'alamat'=>$_POST['alamat'],
				'email'=>$_POST['email'],
				'telepon'=>$_POST['telepon'],
				'username'=>$_POST['username'],
				'password'=>md5($_POST['password']),
				'level'=>$_POST['level']
			);
			$this->Mproses->registrasi($data);
			redirect('home/login');
		}
		public function order(){
			$idpaket=$_POST['id_paket'];
			$iduser=$_POST['id_user'];
			$kodepesan=$_POST['kode_pesan'];
			$tglpesan=$_POST['tgl_pesan'];
			$tglpakai=$_POST['tgl_pakai'];
			$tglselesai=$_POST['tgl_selesai'];

			$inputan=array(
				'id_paket'=>$idpaket,
				'id_user'=>$iduser,
				'kode_pesan'=>$kodepesan,
				'tgl_pesan'=>$tglpesan,
				'tgl_pakai'=>$tglpakai,
				'tgl_selesai'=>$tglselesai
			);
			$this->Mproses->order($inputan);
			redirect('home');
		}
	}
 ?>