<?php 
	class Profil extends CI_Controller{
		function __construct(){
			parent::__construct();
			$this->load->model('Mproses');
			if($this->session->userdata('username')){

			}
			else{
				redirect('home/login');
			}
		}
		public function index(){
			$username=$this->session->userdata('username');
			$user=$this->Mproses->user($username);
			$data=array(
				'judul'=>'Profil',
				'act'=>'',
				'user'=>$user->row()
			);
			$this->load->view('_header', $data);
			$this->load->view('page/user/_profilh');
			$this->load->view('page/user/editp');
			$this->load->view('page/user/_profilf');
			$this->load->view('_footer');
		}
		public function organizerp(){
			$username=$this->session->userdata('username');
			$user=$this->Mproses->user($username)->row();
			$kategori=$this->Mproses->kat();
			$idusr=$user->id_user;
			$organizer=$this->Mproses->getor($idusr);
			$data=array(
				'judul'=>'Organizerku',
				'act'=>'organizerku',
				'user'=>$user,
				'kategori'=>$kategori->result(),
				'organizer'=>$organizer->result(),
			);
			$this->load->view('_header', $data);
			$this->load->view('page/user/_profilh');
			$this->load->view('page/user/organizerp');
			$this->load->view('page/user/_profilf');
			$this->load->view('_footer');
		}
		public function paket(){
			$username=$this->session->userdata('username');
			$user=$this->Mproses->user($username)->row();
			$idusr=$user->id_user;
			$organizer=$this->Mproses->nmor($idusr);
			$paket=$this->Mproses->paket();
			$data=array(
				'judul'=>'Paket',
				'act'=>'paket',
				'user'=>$user,
				'organizer'=>$organizer->result(),
				'paket'=>$paket->result()
			);
			$this->load->view('_header', $data);
			$this->load->view('page/user/_profilh');
			$this->load->view('page/user/paket');
			$this->load->view('page/user/_profilf');
			$this->load->view('_footer');
		}
		public function fasilitas(){
			$username=$this->session->userdata('username');
			$user=$this->Mproses->user($username)->row();
			$idusr=$user->id_user;
			$organizer=$this->Mproses->nmor($idusr);
			$paket=$this->Mproses->paket();
			$paketa=$this->Mproses->paketa();
			$fasilitas=$this->Mproses->getfas();
			$data=array(
				'judul'=>'Fasilitas',
				'act'=>'fasilitas',
				'user'=>$user,
				'organizer'=>$organizer->result(),
				'paket'=>$paket->result(),
				'paketa'=>$paketa->result(),
				'fasilitas'=>$fasilitas->result()
			);
			$this->load->view('_header', $data);
			$this->load->view('page/user/_profilh');
			$this->load->view('page/user/fasilitas');
			$this->load->view('page/user/_profilf');
			$this->load->view('_footer');
		}
		public function pesanan(){
			$username=$this->session->userdata('username');
			$user=$this->Mproses->user($username)->row();
			$pesanan=$this->Mproses->getpesan();
			$idusr=$user->id_user;
			$organizer=$this->Mproses->getor($idusr);
			$data=array(
				'judul'=>'Pesanan',
				'act'=>'pesanan',
				'user'=>$user,
				'pesanan'=>$pesanan->result(),
				'organizer'=>$organizer->result()
			);
			$this->load->view('_header', $data);
			$this->load->view('page/user/_profilh');
			$this->load->view('page/user/pesanan');
			$this->load->view('page/user/_profilf');
			$this->load->view('_footer');
		}
		public function edit_data_diri(){
			$config['upload_path']          = './images/user/';
            $config['allowed_types']        = 'gif|jpg|png';
            $config['max_size']             = 10000;
            $config['max_width']            = 10240;
            $config['max_height']           = 5000;

            $this->load->library('upload', $config);
            $nama=$_POST['nama'];
            $alamat=$_POST['alamat'];
            $foto=$_FILES['foto']['name'];
            $email=$_POST['email'];
            $telepon=$_POST['telepon'];
            $id=$_POST['id'];

            if ( ! $this->upload->do_upload('foto'))
            {
                $data=array(
	            	'nama'=>$nama,
	            	'alamat'=>$alamat,
	            	'email'=>$email,
	            	'telepon'=>$telepon
            	);
            	$this->db->set($data);
            	$this->db->where('id_user', $id);
            	$this->db->update('user', $data);
            }
            else
            {
                $data=array(
	            	'nama'=>$nama,
	            	'alamat'=>$alamat,
	            	'foto'=>$foto,
	            	'email'=>$email,
	            	'telepon'=>$telepon
            	);
            	$this->db->set($data);
            	$this->db->where('id_user', $id);
            	$this->db->update('user', $data);
            }
            redirect('profil');
		}
		public function edit_pass(){
			$curpass=md5($_POST['curpass']);
			$newpass=md5($_POST['newpass']);
			$newpassconfir=md5($_POST['newpassconfir']);
			$username=$_POST['username'];
			$user=$this->Mproses->user($username)->row();
			$crpass=$user->password;
			$id=$user->id_user;
			if($crpass==$curpass){
				if($newpass==$newpassconfir){
					$data=array(
						'password'=>$newpass
					);
					$this->db->set($data);
					$this->db->where('id_user', $id);
					$this->db->update('user', $data);
					redirect('home/login');
				}
				else{
					echo "salah";
				}
			}
			else{
				echo "salah";
			}
		}
		public function edit_username(){
			$username=$_POST['username'];
			$curuser=$_POST['curusername'];
			$newuser=$_POST['newusername'];
			$user=$this->Mproses->user($username)->row();
			$id=$user->id_user;
			if($username==$curuser){
				if($curuser==$newuser){
					echo "benar";
				}
				else{
					echo "salah";
				}

			}
			else{
				echo "salah";
			}
		}
		public function add_organizer(){
			$config['upload_path']          = './images/organizer/';
            $config['allowed_types']        = 'gif|jpg|png';
            $config['max_size']             = 10000;
            $config['max_width']            = 10240;
            $config['max_height']           = 7680;

            $this->load->library('upload', $config);

            $id_user=$_POST['id_user'];
            $id_or=$_POST['id_or'];
           	$id_kategori=$_POST['id_kategori'];
           	$nama_or=$_POST['nama_or'];
           	$slogan=$_POST['slogan'];
           	$foto=$_FILES['foto']['name'];
           	$status='1';

           	if(isset($_POST['add_or'])){

	            if ($this->upload->do_upload('foto'))
	            {
	            	$data=array(
	            		'id_user'=>$id_user,
	            		'id_kategori'=>$id_kategori,
	            		'nama_or'=>$nama_or,
	            		'slogan'=>$slogan,
	            		'fotor'=>$foto,
	            		'status'=>$status
	            	);
	            	$this->db->insert('organizer', $data);
	            	redirect('profil/organizerp');
	            }
	            else
	            {
	                    redirect('profil/organizerp#open-modal');
	            }
	        }
	        else if(isset($_POST['edit_or'])){
	        	if ($this->upload->do_upload('foto'))
	            {
	            	$data=array(
	            		'id_user'=>$id_user,
	            		'id_kategori'=>$id_kategori,
	            		'nama_or'=>$nama_or,
	            		'slogan'=>$slogan,
	            		'fotor'=>$foto,
	            		'status'=>$status
	            	);
	            	$this->db->set($data);
	            	$this->db->where('id_organizer', $id_or);
	            	$this->db->update('organizer', $data);
	            	redirect('profil/organizerp');
	            }
	            else
	            {
	                $data=array(
	            		'id_user'=>$id_user,
	            		'id_kategori'=>$id_kategori,
	            		'nama_or'=>$nama_or,
	            		'slogan'=>$slogan,
	            		'status'=>$status
	            	);
	            	$this->db->set($data);
	            	$this->db->where('id_organizer', $id_or);
	            	$this->db->update('organizer', $data);
	            	redirect('profil/organizerp');
	            }
	        }
		}
		public function add_paket(){
			if(isset($_POST['add_paket'])){
				$inputan=$this->input->post(null, FALSE);
				$this->Mproses->in_paket($inputan);
			}
			if(isset($_POST['edit_paket'])){
				$inputan=$this->input->post(null, FALSE);
				$this->Mproses->edit_paket($inputan);
			}
			redirect('profil/paket');
		}
		public function add_fas(){
			if(isset($_POST['add_fas'])){
				$inputan=$this->input->post(null, FALSE);
				$this->Mproses->add_fas($inputan);
			}
			else if(isset($_POST['edit_fas'])){
				$inputan=$this->input->post(null, FALSE);
				$this->Mproses->edit_fas($inputan);	
			}
			redirect('profil/fasilitas');
		}
		public function del_pesan($id){
			$this->db->where('id_pesan', $id);
			$this->db->delete('pesanan');
			redirect('profil/pesanan');
		}
		public function detail_pesanan($id){
			$username=$this->session->userdata('username');
			$user=$this->Mproses->user($username)->row();
			$pesanan=$this->Mproses->getpsn($id);
			$data=array(
				'judul'=>'detail',
				'act'=>'',
				'user'=>$user,
				'pesanan'=>$pesanan->row()
			);
			$this->load->view('_header', $data);
			$this->load->view('page/user/_profilh');
			$this->load->view('page/user/detail_p');
			$this->load->view('page/user/_profilf');
			$this->load->view('_footer');
		}
	}
 ?>