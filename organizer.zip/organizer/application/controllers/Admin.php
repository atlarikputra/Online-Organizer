<?php 
	class Admin extends CI_Controller{
		function __construct(){
			parent::__construct();
			$this->load->model('Madmin');
			if($this->session->userdata('username')){

			}
			else{
				redirect('home/login');
			}
		}
		public function index(){
			$data=array(
				'judul'=>'Admin',
				'act'=>'home'
			);
			$this->load->view('page/admin/_header', $data);
			$this->load->view('page/admin/home');
			$this->load->view('page/admin/_footer');
		}
		public function kategori(){
			$kategori=$this->Madmin->getkat();
			$data=array(
				'judul'=>'kategori',
				'act'=>'kategori',
				'kategori'=>$kategori->result()
			);
			$this->load->view('page/admin/_header', $data);
			$this->load->view('page/admin/kategori');
			$this->load->view('page/admin/_footer');
		}
		public function organizer(){
			$organizer=$this->Madmin->getor();
			$data=array(
				'judul'=>'Organizer',
				'act'=>'organizer',
				'organizer'=>$organizer->result()
			);
			$this->load->view('page/admin/_header', $data);
			$this->load->view('page/admin/organizer');
			$this->load->view('page/admin/_footer');
		}
		public function pesanan(){
			$data=array(
				'judul'=>'Pesanan',
				'act'=>'pesanan'
			);
			$this->load->view('page/admin/_header', $data);
			$this->load->view('page/admin/pesanan');
			$this->load->view('page/admin/_footer');
		}
		public function add_kat(){
			if(isset($_POST['tambah'])){
				$inputan=$this->input->post(null, FALSE);
				$this->Madmin->add_kat($inputan);
			}
			else if(isset($_POST['edit'])){
				$inputan=$this->input->post(null, FALSE);
				$this->Madmin->edit_kat($inputan);	
			}
			redirect('admin/kategori');
		}
		public function del_kat($id){
			$this->db->where('id_kategori', $id);
			$this->db->delete('kategori');
			redirect('admin/kategori');
		}
		public function verif($id){
			$tgl=date("Y-m-d");
			$param=array(
				'tgl_verif'=>$tgl,
				'status'=>'0'
			);
			$this->db->set($param);
			$this->db->where('id_organizer', $id);
			$this->db->update('organizer', $param);
			redirect('admin/organizer');
		}
		public function unverif($id){
			$tgl=date("Y-m-d");
			$param=array(
				'tgl_verif'=>$tgl,
				'status'=>'1'
			);
			$this->db->set($param);
			$this->db->where('id_organizer', $id);
			$this->db->update('organizer', $param);
			redirect('admin/organizer');
		}
		public function del_or($id){
			$this->db->where('id_organizer', $id);
			$this->db->delete('organizer');
			redirect('admin/organizer');
		}
	}
 ?>