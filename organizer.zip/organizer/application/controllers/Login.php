<?php 
	class Login extends CI_Controller{
		function __construct(){
			parent::__construct();
			$this->load->model('Mproses');
		}
		public function auth(){
			$user=$_POST['username'];
			$pass=md5($_POST['password']);
			$query=$this->Mproses->proses($user, $pass);
			$cek=count($query);
			if($cek>0){
				$level=$query->level;
				$this->session->set_userdata('username', $user);
				if($level=='user'){
					redirect('home');
				}
				else if($level=='admin'){
					redirect('admin');
				}
			}
			else{
				redirect('home/login');
			}
		}
		public function logout(){
			$this->session->sess_destroy();
			redirect('home');
		}
	}
 ?>