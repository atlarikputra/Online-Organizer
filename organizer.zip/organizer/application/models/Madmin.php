<?php 
	class Madmin extends CI_Model{
		function getkat(){
			return $this->db->get('kategori');
		}
		public function add_kat($data){
			$param=array(
				'nama_kat'=>$data['nama_kat'],
				'ikon'=>$data['ikon']
			);
			$this->db->insert('kategori', $param);
		}
		public function edit_kat($data){
			$param=array(
				'nama_kat'=>$data['nama_kat'],
				'ikon'=>$data['ikon']
			);
			$this->db->set($param);
			$this->db->where('id_kategori', $_POST['id']);
			$this->db->update('kategori', $param);
		}
		public function getor(){
			$this->db->join('user','user.id_user=organizer.id_user');
			$this->db->join('kategori','kategori.id_kategori=organizer.id_kategori');
			return $this->db->get('organizer');
		}
	}
 ?>