<?php 
	class Mproses extends CI_Model{
		public function proses($user, $pass){
			$this->db->where('username', $user);
			$this->db->where('password', $pass);
			$query=$this->db->get('user')->row();
			return $query;
		}
		public function registrasi($data){
			$param=array(
				'nama'=>$data['nama'],
				'alamat'=>$data['alamat'],
				'email'=>$data['email'],
				'telepon'=>$data['telepon'],
				'username'=>$data['username'],
				'password'=>$data['password'],
				'level'=>$data['level']
			);
			$this->db->insert('user', $param);
		}
		public function user($user){
			$this->db->where('username', $user);
			$query=$this->db->get('user');
			return $query;
		}
		public function kat(){
			$this->db->select('*');
			$this->db->from('kategori');
			$query=$this->db->get();
			return $query;
		}
		public function getor($id){
			$this->db->where('id_user', $id);
			$this->db->join('kategori','kategori.id_kategori=organizer.id_kategori');
			$query=$this->db->get('organizer');
			return $query;
		}
		public function nmor($id){
			$this->db->where('id_user', $id);
			$query=$this->db->get('organizer');
			return $query;
		}
		public function in_paket($data){
			$param=array(
				'id_organizer'=>$data['id_organizer'],
				'nama_p'=>$data['nama_p'],
				'harga'=>$data['harga']
			);
			$this->db->insert('paket', $param);
		}
		public function edit_paket($data){
			$param=array(
				'id_organizer'=>$data['id_organizer'],
				'nama_p'=>$data['nama_p'],
				'harga'=>$data['harga']
			);
			$this->db->set($param);
			$this->db->where('id_paket', $_POST['id']);
			$this->db->update('paket', $param);
		}
		public function paket(){
			$this->db->join('organizer', 'organizer.id_organizer=paket.id_organizer');
			return $this->db->get('paket');
		}
		public function paketa(){
			$this->db->join('organizer', 'organizer.id_organizer=paket.id_organizer');
			$this->db->group_by('paket.id_organizer');
			return $this->db->get('paket');
		}
		public function add_fas($data){
			$param=array(
				'id_organizer'=>$data['id_organizer'],
				'id_paket'=>$data['id_paket'],
				'fasilitas'=>$data['fasilitas']
			);
			$this->db->insert('fasilitas', $param);
		}
		public function getfas(){
			$this->db->join('paket','paket.id_paket=fasilitas.id_paket');
			return $this->db->get('fasilitas');
		}
		public function edit_fas($data){
			$param=array(
				'id_organizer'=>$data['id_organizer'],
				'id_paket'=>$data['id_paket'],
				'fasilitas'=>$data['fasilitas']
			);
			$this->db->set($param);
			$this->db->where('id_fasilitas', $_POST['id']);
			$this->db->update('fasilitas', $param);
		}
		public function getkat(){
			return $this->db->get('kategori');
		}
		public function getorw($id){
			$this->db->where('status', '0');
			$this->db->where('id_kategori', $id);
			$this->db->join('user','user.id_user=organizer.id_user');
			$query=$this->db->get('organizer');
			return $query;
		}
		public function gtpaket($id){
			$this->db->where('id_organizer', $id);
			$query=$this->db->get('paket');
			return $query;
		}
		public function getpaketid($id){
			$this->db->where('id_paket', $id);
			return $this->db->get('paket');
		}
		public function getorid($id){
			$this->db->where('id_organizer', $id);
			return $this->db->get('organizer');
		}
		public function gtuserid($id){
			$this->db->where('id_user', $id);
			return $this->db->get('user');
		}
		public function gtuser($user){
			$this->db->where('username', $user);
			return $this->db->get('user');
		}
		function buat_kode()   {    
		  $this->db->select('RIGHT(pesanan.kode_pesan,2) as kode', FALSE);
		  $this->db->order_by('kode_pesan','DESC');    
		  $this->db->limit(1);     
		  $query = $this->db->get('pesanan');      //cek dulu apakah ada sudah ada kode di tabel.    
		  if($query->num_rows() <> 0){       
		   //jika kode ternyata sudah ada.      
		   $data = $query->row();      
		   $kode = intval($data->kode) + 1;     
		  }
		  else{       
		   //jika kode belum ada      
		   $kode = 1;     
		  }
		  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT);    
		  $kodejadi = "PSN-".$kodemax;     
		  return $kodejadi;  
		 }
		public function order($data){
			$param=array(
				'id_paket'=>$data['id_paket'],
				'id_user'=>$data['id_user'],
				'kode_pesan'=>$data['kode_pesan'],
				'tgl_pesan'=>$data['tgl_pesan'],
				'tgl_pakai'=>$data['tgl_pakai'],
				'tgl_selesai'=>$data['tgl_selesai']
			);
			$this->db->insert('pesanan', $param);
		}
		public function getpesan(){
			$this->db->join('paket','paket.id_paket=pesanan.id_paket');
			return $this->db->get('pesanan');
		}
		public function org(){
			return $this->db->get('organizer');
		}
		public function getpsn($id){
			$this->db->where('id_pesan', $id);
			$this->db->join('user','user.id_user=pesanan.id_user');
			return $this->db->get('pesanan');
		}
	}
 ?>